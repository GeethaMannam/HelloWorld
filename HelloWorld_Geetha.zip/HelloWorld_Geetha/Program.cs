﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldAPI;

namespace HelloWorld_Geetha
{
    class Program
    {
        static void Main(string[] args)
        {
            HelloWorldApp app = new HelloWorldApp();
            app.ProcessMessage();
           
        }
    }
}
