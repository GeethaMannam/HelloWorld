﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldModel.Interfaces;
using System.Configuration;

namespace HelloWorldModel.Model
{
    public class AppSettings : IAppSettings
    {
      public string Getvalue(string name)
        {
            return ConfigurationManager.AppSettings.Get(name);
        }
    }
}
