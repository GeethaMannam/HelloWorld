﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldModel.Interfaces;

namespace HelloWorldModel.Model
{
    public class Database : IDatabase
    {
        
          IAppSettings appsetting = new AppSettings();


        public string GetDBConnectionString()   
        {
            // Can get strings from resource files/database etc .. for time being I am leaving this out with hard coding.
        return  appsetting.Getvalue("DBConnectionstring");
        }

        public void Write(Data data)
        {
           // throw NotImplementedException;

        }
    }
}
    

