﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldModel.Interfaces;

namespace HelloWorldModel.Model
{
   public class ConsoleApp : Iconsole, IData
    {
        public Data data { get; set; }
        public IAppSettings appSettings { get; set; }
        public  ConsoleApp()
        {
            this.data = new Data();
            appSettings = new AppSettings();
        }

       
        public Data GetData()
        {
            this.data.Message = appSettings.Getvalue("Message");
            return data;
        }
      
        public void Write(Data data)
        {
            Console.Write(data.Message);
        }
    }
}
