﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldModel.Interfaces;

namespace HelloWorldModel.Model
{
   public class Data
    {
        public string Message { get; set; }
    }
}
