﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldModel.Interfaces;
using HelloWorldModel.Model;

namespace HelloWorldAPI
{
    public class HelloWorldApp : IHelloWorldApp
    {
        // This can act as a core API , can wrap this in Web API or WCF to supoort WEB,Mobile, Windows Services eventually.
       public void ProcessMessage()
        {
            IAppSettings appSettings = new AppSettings();
            string AppType = appSettings.Getvalue("AppType");

            if(AppType == "Console")
            {
                ConsoleApp app = new ConsoleApp();

                app.Write(app.GetData());
                Console.ReadKey();
            }

            // TODO for DB and other functionality, can also use the facory design pattern here.

        }
    }
}
